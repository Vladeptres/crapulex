from mistralai import Mistral
from os.path import join as pjoin
from chat_analyser.api.models import ConversationAnalysisResponse
from chat_analyser import config as cf


def load_system_prompt(context_type: str) -> str:
    if context_type not in cf.AVAILABLE_CONTEXTS:
        raise ValueError(
            f"Context type {context_type} not among existing context. Please choose one among : {cf.AVAILABLE_CONTEXTS}"
        )
    with open(pjoin(cf.CONTEXTS_DIR, context_type + ".md"), "r") as f:
        return f.read()


def format_user_prompt(
    users: list[str],
    conversations: list[dict[str, str]],
    pseudo_to_user_id: dict[str, str] | None = None,
) -> str:
    lines = [f"## Users list\n{users}\n\n## Conversations\n{conversations}"]
    if pseudo_to_user_id:
        mapping_lines = "\n".join(f"  {pseudo}: {uid}" for pseudo, uid in pseudo_to_user_id.items())
        lines.append(f"\n\n## Pseudo to user_id mapping (for reference)\n{mapping_lines}")
    return "".join(lines)


def _call_llm(
    client: Mistral,
    model: str,
    system_prompt: str,
    user_prompt: str,
) -> ConversationAnalysisResponse:
    chat_response = (
        client.chat.complete(
            model=model,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
            stream=False,
            response_format={
                "type": "json_object",
                "json_schema": ConversationAnalysisResponse.model_json_schema(),
            },
        )
        .choices[0]
        .message.content
    )
    chat_response = chat_response[chat_response.index("{") : chat_response.rindex("}") + 1]
    return ConversationAnalysisResponse.model_validate_json(chat_response)


def analyse_chat(
    context_type: str,
    users: list[str],
    messages: list[dict[str, str]],
    model: str = cf.MISTRAL_MODEL,
    chunk_size: int = 30,
    pseudo_to_user_id: dict[str, str] | None = None,
) -> ConversationAnalysisResponse:
    """Analyse a party chat and return per-user feedback with badge assignment.

    For conversations under 200 messages a single LLM call is used.
    Larger conversations are chunked and merged.

    Args:
        context_type: Context name (e.g. "party").
        users: List of participant pseudos.
        messages: List of {"user": pseudo, "content": text} dicts.
        model: Mistral model to use.
        chunk_size: Messages per chunk when chunking is needed.
        pseudo_to_user_id: Optional mapping of pseudo → user_id for badge award routing.
    """
    system_prompt = load_system_prompt(context_type)

    # Single call for small conversations (better attribution, cheaper)
    if len(messages) <= 200:
        user_prompt = format_user_prompt(users, messages, pseudo_to_user_id)
        with Mistral(api_key=cf.API_KEY) as client:
            return _call_llm(client, model, system_prompt, user_prompt)

    # Chunk-then-merge for large conversations
    chunks = [messages[i : i + chunk_size] for i in range(0, len(messages), chunk_size)]
    chunk_analyses = []

    with Mistral(api_key=cf.API_KEY) as client:
        total = len(chunks)
        for i, chunk in enumerate(chunks):
            chunk_prompt = (
                f"{system_prompt}\n\n"
                f"IMPORTANT: You are analyzing chunk {i + 1} of {total} from a larger conversation. "
                f"This chunk covers messages {chunk_size * i}–{chunk_size * (i + 1)} "
                f"(total: {len(messages)} messages). Analyze only this subset."
            )
            user_prompt = format_user_prompt(users, chunk, pseudo_to_user_id)
            chunk_analyses.append(_call_llm(client, model, chunk_prompt, user_prompt))

        # Build per-user message counts for weighted merge hint
        user_msg_counts: dict[str, int] = {}
        for msg in messages:
            u = msg.get("user", "")
            user_msg_counts[u] = user_msg_counts.get(u, 0) + 1

        weight_hint = "\n".join(
            f"  {u}: {c} messages ({100 * c // len(messages)}% of conversation)"
            for u, c in sorted(user_msg_counts.items(), key=lambda x: -x[1])
        )

        chunk_summaries = [
            f"## Chunk {i + 1} Analysis\n{a.model_dump_json(indent=2)}"
            for i, a in enumerate(chunk_analyses)
        ]

        merge_prompt = (
            f"{system_prompt}\n\n"
            f"IMPORTANT: Merge {total} chunk analyses into ONE comprehensive analysis.\n"
            f"Weight users proportionally to their message count:\n{weight_hint}\n"
            f"Low-volume users must still get a badge — don't omit anyone."
        )
        merge_user_prompt = (
            f"## Users list\n{users}\n\n"
            f"## Chunk Analyses to Merge\n" + "\n\n".join(chunk_summaries)
        )
        if pseudo_to_user_id:
            mapping_lines = "\n".join(f"  {p}: {uid}" for p, uid in pseudo_to_user_id.items())
            merge_user_prompt += f"\n\n## Pseudo to user_id mapping\n{mapping_lines}"

        return _call_llm(client, model, merge_prompt, merge_user_prompt)
