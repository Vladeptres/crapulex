from pydantic import BaseModel
from chat_analyser import config as cf


class ConversationAnalysisRequest(BaseModel):
    context_type: str
    model: str = cf.MISTRAL_MODEL
    messages: list[dict[str, str]]
    users: list[str]
    max_attempts: int = 3


class UserFeedback(BaseModel):
    summary: str
    emoji: str
    badge: str = ""
    wildness_score: int = 0


class ConversationAnalysisResponse(BaseModel):
    summary: str
    users_feedback: dict[str, UserFeedback]
    party_title: str = ""
    quote_of_the_night: str = ""
    quote_author: str = ""


class PostContextRequest(BaseModel):
    context_type: str
    context: str


class PostContextResponse(BaseModel):
    available_contexts: list[str]
